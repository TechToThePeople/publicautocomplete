cj(function($) {
  $('#current_employer').crmAutocomplete({'action':'publicget'},{'field':'sort_name'});
});
